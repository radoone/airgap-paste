# AirGap Paste Hex Node v1

Samostatný šesťuholníkový EDC model podľa konceptu `16_mx_hex_node.jpg`.

Obsahuje XIAO ESP32-S3 lôžko, USB-C otvor 13,2 × 7,0 mm, MX otvor 14,10 × 14,10 mm v platni 1,50 mm, 5 mm LED a svetlovod, anténnu plochu, EDC očko Ø5 mm, ochranný hex prstenec a 4× M3×10 spojenie s M3 maticami.

Tlač: Bambu Lab A1, 0,4 mm tryska, 0,20 mm vrstva, 3 steny, 20 % gyroid. Samostatné STL sú už orientované na tlač. Telo, základňa a prstenec: PLA/PETG. Klávesa a svetlovod: translucent PETG pre podsvietenie.

Najprv vytlač `06_mx_fit_coupon_hex.stl` a over konkrétny MX clone. CAD, uzavreté siete a slicer sa dajú overiť programovo, no USB kábel, mechanika tlačidla, LED efekt, anténa a M3 skrutky musia prejsť fyzickým testom.
