# AirGap Paste — celé prototypy na samostatných A1 platniach

Každý 3MF súbor obsahuje práve jeden prototyp a všetky diely potrebné na jeho zostavenie. Diely sú automaticky rozložené na jednej platni Bambu Lab A1 a používajú jeden PLA filament, takže ich možno vytlačiť bez AMS.

## Platňa 1 — EDC Pocket Vault

Súbor: `01_EDC_Pocket_Vault_ALL_PARTS_A1_PLA.3mf`

Obsahuje šesť dielov: horný plášť, spodný podvozok, MX klávesu, svetlovod a obe ochranné ramená. MX skúšobná mierka nie je na hlavnej platni, pretože nie je súčasťou zostaveného zariadenia; zostáva samostatne v priečinku modelu.

Podpery sú vypnuté. Pre funkčný svetelný efekt možno túto prvú skúšobnú tlač spraviť celú z natural/translucent PLA; pre finálny vzhľad sú v priečinku EDC modelu pripravené aj samostatné čierne a translucent 3MF diely.

## Platňa 2 — Mini v3

Súbor: `02_Mini_v3_ALL_PARTS_A1_PLA.3mf`

Obsahuje tri diely: plášť, horné tlačidlo a spodný elektronický podvozok. Zapnuté sú automatické snug podpery iba z podložky, pretože spodný diel obsahuje vyvýšené lôžko spínača.

## Pred spustením

V Bambu Studio skontrolujte vybranú A1 tlačiareň, 0,4 mm trysku a skutočne vložený typ PLA. Neškálujte modely; projekty sú v milimetroch a pri 100 % veľkosti.
